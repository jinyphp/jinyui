<?php

namespace Facade\FlareClient\Contracts;

interface ProvidesFlareContext
{
    public function context(): array;
}
